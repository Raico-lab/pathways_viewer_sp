"""種の設定（出芽酵母 sc・分裂酵母 sp）。

アプリと道具は、環境変数 PATHWAYS_SPECIES（sc か sp。省略時は sc）で種を決める。
同梱データの置き場所は sc が data/、sp が data/sp/。各 PC の保存先も sp は PathwaysViewer/sp/ に分ける。
種ごとの元データの取り込みは tools/import_sources.py（sc）と tools/import_sp.py（sp）。計画は docs/POMBE_PLAN.md。
"""
import os
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Species:
    code: str                  # "sc" / "sp"
    latin: str                 # 学名
    taxon: str                 # NCBI の分類番号（BioGRID・Complex Portal・UniProt で使うもの）
    data_subdir: tuple[str, ...]   # data/ の下の置き場所（sc は data/ そのもの）
    gene_name_upper: bool      # 遺伝子名を大文字で書くか（sc: TOR1、sp: tor1）
    systematic_pattern: str    # 系統名の形
    pubmed_filter: str         # PubMed の検索に付ける種名の絞り込み
    biogrid_organism: str      # BioGRID の生物ごとのファイル名に入る名前
    reference_db: str          # 遺伝子名の基準にするデータベース

    @property
    def title(self) -> str:
        return f"Pathways viewer for {self.latin}"

    @property
    def title_html(self) -> str:
        return f"Pathways viewer for <i>{self.latin}</i>"

    def is_systematic(self, name: str) -> bool:
        return re.fullmatch(self.systematic_pattern, name, flags=re.IGNORECASE) is not None


SC = Species(code="sc", latin="Saccharomyces cerevisiae", taxon="559292", data_subdir=(), gene_name_upper=True,
             systematic_pattern=r"Y[A-P][LR]\d{3}[WC](-[A-Z])?|Q\d{4}", pubmed_filter='"Saccharomyces cerevisiae"[MeSH Terms]',
             biogrid_organism="Saccharomyces_cerevisiae_S288c", reference_db="SGD")
SP = Species(code="sp", latin="Schizosaccharomyces pombe", taxon="284812", data_subdir=("sp",), gene_name_upper=False,
             systematic_pattern=r"SP[ABCMN][A-Z0-9]*\.\d{2}c?|SPRRNA\.\d+|SPMIT\.\d+|SPNCRNA\.\d+",
             pubmed_filter='"Schizosaccharomyces pombe"[MeSH Terms] OR "fission yeast"[Title/Abstract]',
             biogrid_organism="Schizosaccharomyces_pombe_972h", reference_db="PomBase")
SPECIES = {s.code: s for s in (SC, SP)}
ENV = "PATHWAYS_SPECIES"


def current() -> Species:
    code = os.environ.get(ENV, "").strip().lower() or "sc"
    if code not in SPECIES:
        raise SystemExit(f"{ENV} は sc か sp にしてください: {code}")
    return SPECIES[code]


def select(code: str) -> Species:
    """道具の --species の値を環境変数に写して、この後に読み込む部品にも効かせる。"""
    os.environ[ENV] = code
    return current()
